package vagueobjects.rf.clustering

import vagueobjects.rf.Tree

trait Forest {
  val trees:Array[Tree]
}
