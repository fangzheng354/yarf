import boto.ec2
import time
import boto.ec2.networkinterface
from boto.ec2.blockdevicemapping import BlockDeviceType, BlockDeviceMapping

def create_sg(): 
	ec2 = boto.ec2.connect_to_region('us-east-1')
	sg = ec2.create_security_group("rf-temp", "test sg", vpc_id="vpc-fca41a97")
	sg.authorize(ip_protocol="tcp", from_port="22", to_port="22", cidr_ip="0.0.0.0/0")

# ec2.terminate_instances(instance_id)

def create(name):
    ec2 = boto.ec2.connect_to_region('us-east-1')
	#image = ec2.get_image("ami-1624987f")
    xvdb = BlockDeviceType()
    xvdb.ephemeral_name = "ephemeral0"
    bdm = BlockDeviceMapping()
    bdm['/dev/xvdb'] = xvdb
    
    #  subnet-c9a51ba2   "VpcId": "vpc-fca41a97",
    interface = boto.ec2.networkinterface.NetworkInterfaceSpecification(subnet_id='subnet-c9a51ba2',groups=['sg-a730cec2'],associate_public_ip_address=False)
    interfaces = boto.ec2.networkinterface.NetworkInterfaceCollection(interface)                                                                
    
    script= """#!/bin/bash
    sudo mkdir data
    sudo mount /dev/xvdb data
    sudo ln -s /dev/xvdb /home/ec2-user/data
    """
                                                                    
    reservation=ec2.run_instances("ami-1624987f",key_name="sf-topicana",instance_type="m1.large",network_interfaces=interfaces, block_device_map=bdm, user_data=script)
    instance = reservation.instances[0]
    status = instance.update()
    while status == 'pending':
        time.sleep(10)
        status = instance.update()
        
    if status == 'running':
        instance.add_tag("Name",name)
        instance.add_tag("bv:nexus:team","data-science")
        instance.add_tag("bv:nexus:vpc","qa")  
        return instance
    else:
        print('Instance status: ' + status)
        return None
    
    
        