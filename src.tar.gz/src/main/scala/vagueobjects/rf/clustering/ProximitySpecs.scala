package vagueobjects.rf.clustering

trait ProximitySpecs {
  val support:Int
  val numTrees:Int
  val expectedSize:Int
}
